# ddos
# By @xYz_CriminalL
@SERVER FREEZE 